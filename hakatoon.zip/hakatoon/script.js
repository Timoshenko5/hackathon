document.addEventListener('DOMContentLoaded', function() {
    const mapAreas = document.querySelectorAll('area');

    mapAreas.forEach(area => {
        area.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = area.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
                highlightSection(targetSection);
                playMagicSound(); // Відтворюємо звук
            }
        });
    });

    function highlightSection(section) {
        section.classList.add('highlight');
        setTimeout(() => {
            section.classList.remove('highlight');
        }, 1500);
    }

    createFireflies(20); // Створюємо 20 світлячків

    function createFireflies(count) {
        const body = document.querySelector('body');
        for (let i = 0; i < count; i++) {
            const firefly = document.createElement('div');
            firefly.classList.add('firefly');
            firefly.style.top = `${Math.random() * 100}vh`;
            firefly.style.left = `${Math.random() * 100}vw`;
            body.appendChild(firefly);
        }
    }

    function playMagicSound() {
        const sound = new Audio('magic-sound.mp3');
        sound.volume = 0.5; // Гучність звуку
        sound.play();
    }
});
